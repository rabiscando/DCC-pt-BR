# dcc-pt-BR

DCC Dungeon Crawl Classics game system brazilian portuguese Translation for Foundry Virtual TableTop.

## informations

Tradução do sistema DCC para o Foundry em português brasileiro

## installation

- Adição aos módulos do Foundry VTT via o arquivo de manifesto: https://raw.githubusercontent.com/rabiscando/DCC-pt-BR/main/dcc-pt-br/module.json
- Ativar na opções do Foundry o idioma Português

## Crédits
Contribuintes: NinjaDePantufas

## Changelogs
### 0.0.1
- Validando a primeira versão deste módulo online
### 0.0.2
- traduzir todos os textos do módulo no sistema DCC
- corrigir erros ortográficos
- averiguar sintaxe e glossário do sistema
